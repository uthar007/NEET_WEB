package Pages;

import com.qa.Base.TestBase;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

public class Homepage extends TestBase {
    @FindBy(xpath = "//*[@id=\"subject-wrap\"]/div/div[1]/a/div/div/div/h5")
    public WebElement one;

    @FindBy(xpath = "//*[@id=\"subject-wrap\"]/div/div[1]/a/div/div/div/h5")
    public WebElement two;

    @FindBy(xpath = "//*[@id=\"subject-wrap\"]/div/div[1]/a/div/div/div/h5")
    public WebElement three;

    @FindBy(xpath = "//*[@id=\"subject-wrap\"]/div/div[1]/a/div/div/div/h5")
    public WebElement four;

    //----Menu------//
    @FindBy(xpath = "//*[@id=\"accordion-menu\"]/li[3]/a")
    public WebElement myprofile;



    @FindBy(xpath = "//*[@id=\"accordion-menu\"]/li[8]/a")
    private WebElement logout;

    @FindBy(xpath = "//*[@id=\"bd-logout\"]/div/div/div[1]/div/div")
    private WebElement logoutpop;

    @FindBy(xpath = "//*[@id=\"bd-logout\"]/div/div/div[2]/div/button[2]")
    private WebElement logoutok;

    public void scolltilllogout() throws InterruptedException {
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",logout);
        Thread.sleep(500);
    }
    public void logout(){
        elementtoeclickable(logout);
        waitForVisibility(logoutpop);
        String popup=logoutpop.getText();
        System.out.println(popup);
        Assert.assertTrue(popup.contains("Are you sure you want to logout?"));
        click(logoutok);
    }

    public void selectsub(WebElement e){
        click(e);
    }
}
