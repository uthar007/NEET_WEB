package com.qa.Testcase;

public class Forgotpage_test {

}
