package com.qa.Testcase;

import Pages.Signinpage;
import com.qa.Base.TestBase;
import org.openqa.selenium.Alert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.lang.reflect.Method;

public class Signinpage_test extends TestBase {
    Signinpage signinpage;
    @BeforeMethod
    public void beforeMethod(Method m)
    {
        signinpage=new Signinpage();
        System.out.println("\n" + "****** Starting Test:"+ m.getName() +"*****"+"\n");
    }

    @Test(priority = 1)
    public void gettitle(){
        String title=driver.getTitle();
        softAssert(title,"M-tutor NEET");
    }
    @Test(priority = 2)
    public void forgotlinkcheck(){
        signinpage.forgotlink();
        driver.navigate().back();
    }
    @Test(priority = 3)
    public void signuplinkcheck(){
        signinpage.signuplink();
        driver.navigate().back();
    }
    @Test(priority = 4)
    public void emptysigin() {
        signinpage.pressSignin();
        softAssert(signinpage.errortextmob.getText(),"Please Enter Mobile Number");
        softAssert(signinpage.errortextpwd.getText(),"Please Enter Password");
    }
    @Test(priority = 5)
    public void mobonlysigin()  {
        signinpage.entermobile("8667651940");
        signinpage.pressSignin();
        softAssert(signinpage.errortextpwd.getText(),"Please Enter Password");
    }
    @Test(priority = 6)
    public void pwdonlysigin()   {
        signinpage.clearall();
        signinpage.enterpwd("abc@123");
        signinpage.pressSignin();
        softAssert(signinpage.errortextmob.getText(),"Please Enter Mobile Number");
    }
  /*  @Test(priority = 7)
    public void unregistereduser() throws InterruptedException {
        signinpage.clearall();
        signinpage.entermobile("8555525222");
        signinpage.enterpwd("abc@123");
        signinpage.pressSignin();
        try {
            //String actualtext=driver.switchTo().alert().getText();
            softAssert(signinpage.errorpopup.getText(),"Sorry ! You don't have an account, proceed to Register");

            // swap(signinpage.btnerrorok);
            click(signinpage.btnerrorok);
        }catch (Exception e){
           e.printStackTrace();
        }

    }
    @Test(priority = 8)
    public void invalidCredentials()   {
        signinpage.clearall();
        signinpage.entermobile("825222");
        signinpage.enterpwd("abc123");
        signinpage.pressSignin();
        //String actualtext=driver.switchTo().alert().getText();
        softAssert(signinpage.errorpopup.getText(),"Invalid Password");
        //swap(signinpage.btnerrorok);
        click(signinpage.btnerrorok);
    }*/
    @Test(priority = 9)
    public void Siginusingvalidinputs()   {
        signinpage.entermobile("8667651940");
        signinpage.enterpwd("abc@123");
        signinpage.pressSignin();
    }


}
