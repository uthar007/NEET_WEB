package Pages;

import com.qa.Base.TestBase;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class Profilepage extends TestBase {

    @FindBy(id = "profilename")
    private WebElement pname;

    @FindBy(id = "profileemail")
    private WebElement pemail;

    @FindBy(id = "location")
    private WebElement plocation;

    @FindBy(xpath ="//button[@class='login100-form-btn' and not(@disable)]")
    private WebElement btnsave;

    @FindBy(css = "body > div.sweet-alert.showSweetAlert.visible > p")
    public WebElement errorpopup;

    @FindBy(css="body > div.sweet-alert.showSweetAlert.visible > div.sa-button-container > div > button")
    private WebElement btnok;

    @FindBy(xpath = "/html/body/div[3]/div/div/div[1]/div/div/h5/a")
    public WebElement backarrow;

    @FindBy(id = "wizard-picture")
    private WebElement uploadpic;



    public void enterpname(String name){
        sendkeys(pname,name);
    }
    public void enterpemail(String email){
        sendkeys(pemail,email);
    }
    public void enterpLoc(String loc){
        sendkeys(plocation,loc);
    }
    public void presssave() {
        JavascriptExecutor executor = (JavascriptExecutor) driver;
        executor.executeScript("arguments[0].click();", btnsave);
    }
    public void clickokbtn() {
        waitForVisibility(btnok);
        JavascriptExecutor executor = (JavascriptExecutor) driver;
        executor.executeScript("arguments[0].click();", btnok);
    }
    public void setUploadpicrandom(){
        WebElement e=driver.findElement(By.id("wizard-picture"));
        Random rand = new Random();
        List<String> givenList = Arrays.asList
                ("C:\\Users\\Uk\\Desktop\\WFH\\NEET\\NEET_WEB\\src\\main\\resources\\" +
                                "File upload\\1mbjpeg.jpg",
                        "C:\\Users\\Uk\\Desktop\\WFH\\NEET\\NEET_WEB\\src\\main\\" +
                                "resources\\File upload\\SamplePNGImage_500kbmb.png",
                        "C:\\Users\\Uk\\Desktop\\WFH\\NEET\\NEET_WEB\\src\\main\\resources\\" +
                                "File upload\\SampleJPGImage_2mbmb.jpg",
                        "C:\\Users\\Uk\\Desktop\\WFH\\NEET\\NEET_WEB\\src\\main\\resources\\" +
                                "File upload\\file_example_PNG_1MB.png");

        int numberOfElements =4 ;

        for (int i = 0; i < numberOfElements; i++) {
            int randomIndex = rand.nextInt(givenList.size());
            String randomElement = givenList.get(randomIndex);
            e.sendKeys(randomElement);
        }
    }
    public void uploadBigfile() throws InterruptedException {
        WebElement e=driver.findElement(By.id("wizard-picture"));
        e.sendKeys("C:\\Users\\Uk\\Desktop\\WFH\\NEET\\NEET_WEB\\src\\main\\resources\\" +
                "File upload\\SampleJPGImage_5mbmb (1).jpg");
    }
    public void uploadInvalidfile() throws InterruptedException {
        WebElement e=driver.findElement(By.id("wizard-picture"));
        e.sendKeys("C:\\Users\\Uk\\Desktop\\WFH\\NEET\\NEET_WEB\\src\\main\\resources\\" +
                "File upload\\2mb.pdf");
    }
    public void clearall(){
        clear(pname);
        clear(pemail);
        clear(plocation);
    }
}
